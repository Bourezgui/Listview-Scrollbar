{'name':'Fixed list view header',
 'description':'Fixed list view header',  
 'author':'Smart it',
 'depends':['web','base'],
 'installable': True,
  'data':['view/js_extending.xml',],
  
    }